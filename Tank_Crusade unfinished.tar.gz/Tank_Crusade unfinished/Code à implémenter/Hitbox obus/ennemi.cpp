#include <iostream>
using namespace std;
int main()
{
var obus = {x: 0, y: 0, width: 10, height: 10}
var ennemi = {x: 0, y: 0, width: 171, height: 125}

if (rect1.x < rect2.x + rect2.width &&
   rect1.x + rect1.width > rect2.x &&
   rect1.y < rect2.y + rect2.height &&
   rect1.height + rect1.y > rect2.y) 
{
    // collision détectée !  SORTIE
}



  return 0;
}
