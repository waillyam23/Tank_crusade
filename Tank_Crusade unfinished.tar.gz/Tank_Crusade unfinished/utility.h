#ifndef __UTILITY_H__
#define __UTILITY_H__

#include <iostream>
#include "entities.h"

//Perte de hp du joueur
void hpLossPlayer(player* P);

//Perte de hp des tanks ennemis
void hpLossTank(tank ennemi);

void procedural_generation(SDL_Point t[]);

void procedural_init(SDL_Point t[]);

void surLaLigneP(player* P, SDL_Point t[]);

void surLaLigneE(tank* T, SDL_Point t[]);

void cameraCentered(SDL_Rect* camera, player* P);

bool colliProjEnnemi (bullet* box1, tank* box2);

bool colliProjJoueur (bullet* box1, player* box2);

bool colliProjBatiment(bullet* box1, bat* box2);

void tir(bullet* B);

void tir_ennemi(bullet* B);

bool colliRam (player* box1, tank* box2);

SDL_Rect camera_offset(player P, SDL_Rect A);

bool terrain_hit(bullet B, SDL_Point t[30]);

SDL_Point pointSurSegment(SDL_Point A, SDL_Point B, int x);

#endif
