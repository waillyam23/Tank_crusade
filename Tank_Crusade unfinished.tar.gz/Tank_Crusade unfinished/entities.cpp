#ifndef __ENTITIES_CPP__
#define __ENTITIES_CPP__

#include <iostream>

#include "entities.h"
#include "defines.h"

void initPlayer (player* P1)
{
    (*P1).hp=3;
    (*P1).score=0;
    (*P1).a=0;
    (*P1).c.x=0;
    (*P1).c.y=450;
    (*P1).c.w=PLAYER_W;
    (*P1).c.h=PLAYER_H;
    (*P1).mspeed=20;
    (*P1).bspeed=0.1;
    (*P1).reload=10000;
    (*P1).munition=0;
}

void initEnnemi (tank* T, player* P)
{
    (*T).hp=1;
    (*T).c.x=SCREEN_W + (*P).c.x;
    (*T).c.y=0;
    (*T).c.w=80;
    (*T).c.h=70;
    (*T).a=135;
}

void initBullet (bullet* B, player* P1, SDL_Rect curseur)
{
    (*B).c.x=(*P1).c.x+30;
    (*B).c.y=(*P1).c.y;
    (*B).a=((curseur.y)-(*B).c.y)/15;
    (*B).c.w=30;
    (*B).c.h=20;
    (*B).v=50;
}

void initBullet_e (bullet* B, tank* T1,int* IA)
{
    (*B).c.x=(*T1).c.x-30;
    (*B).c.y=(*T1).c.y-50;

    if(*IA==0)
    (*B).a= abs(rand()%(30));
    if(*IA==1)
    (*B).a -= 20;
    if(*IA==-1)
    (*B).a +=20;

    (*B).c.w=30;
    (*B).c.h=20;
    (*B).v=50;
}
//void initBullet
#endif
