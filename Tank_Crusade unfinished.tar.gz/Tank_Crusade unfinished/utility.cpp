#ifndef __UTILITY_CPP__
#define __UTILITY_CPP__

#include <iostream>
#include <cstdlib>
#include <time.h>

#include "utility.h"
#include "defines.h"

#define MAX SCREEN_H-50
#define MIN 400

//Perte de hp du joueur
void hpLossPlayer(player* P)
{
    (*P).hp-=1;
}

//Perte de hp des tanks ennemis
void hpLossTank(tank ennemi)
{
    ennemi.hp-=1;
    if (ennemi.hp<1)
        std::cout << "supprimer ennemi";
}

void procedural_generation(SDL_Point t[]) // pour un tableau de [30]
{
    for(int i=0; i<29; i++)
    {
        t[i].x=t[i+1].x;
        t[i].y=t[i+1].y;
    }
    int yint = t[28].y+rand()%(CURV) - CURV/2;
    if(yint>MAX || yint<MIN)
            yint=t[28].y-1*(rand()%(CURV) - CURV/2);
    t[29].y=yint;
    t[29].x=t[28].x+rand() % (CURV+50) + 100;
}

void procedural_init(SDL_Point t[])
{
    t[0].x=0;
    t[0].y=800-250;
    int yint;
    for(int i=1; i<30; i++)
    {
        yint = t[i-1].y+rand()%(CURV) - CURV/2;
        if(yint>MAX || yint <MIN)
            yint=t[i-1].y-1*(rand()%(CURV) - CURV/2);
        t[i].y=yint;
        t[i].x=t[i-1].x+rand() % (CURV+50) + 100;
    }
}

void surLaLigneP (player* P, SDL_Point t[])
{
    int i=1;
    while(t[i].x <= (*P).c.x + PLAYER_W/2 )
        i++;

    float dy = t[i].y-t[i-1].y;
    float dx = t[i].x-t[i-1].x;
    float a = dy/dx;
    float b = t[i-1].y - a*t[i-1].x;

    (*P).c.y = a*((*P).c.x + PLAYER_W/2) + b - ((*P).c.h);
}

void surLaLigneE (tank* T, SDL_Point t[])
{
    int i=1;
    while(t[i].x <= (*T).c.x + PLAYER_W/2)
        i++;

    float dy = t[i].y-t[i-1].y;
    float dx = t[i].x-t[i-1].x;
    float a = dy/dx;
    float b = t[i-1].y - a*t[i-1].x;

    (*T).c.y = a*((*T).c.x + PLAYER_W/2) + b - ((*T).c.h);
}

void cameraCentered(SDL_Rect* camera, player* P)
{
    (*camera).x = ( (*P).c.x + PLAYER_W / 2 ) - SCREEN_W / 2;
    (*camera).y = ( (*P).c.y + PLAYER_H / 2 ) - SCREEN_H / 2;
}

bool colliProjEnnemi (bullet* box1, tank* box2)
{
  if(((*box2).c.x >= (*box1).c.x + (*box1).c.w)      // trop à droite
     || ((*box2).c.x + (*box2).c.w <= (*box1).c.x) // trop à gauche
     || ((*box2).c.y >= (*box1).c.y + (*box1).c.h) // trop en bas
     || ((*box2).c.y + (*box2).c.h <= (*box1).c.y))  // trop en haut
          return false;
 else
          return true;
}

//FONCTION collision entre projectile tank et joueur
bool colliProjJoueur (bullet* box1, player* box2)
{
  if(((*box2).c.x >= (*box1).c.x + (*box1).c.w)      // trop à droite
     || ((*box2).c.x + (*box2).c.w <= (*box1).c.x) // trop à gauche
     || ((*box2).c.y >= (*box1).c.y + (*box1).c.h) // trop en bas
     || ((*box2).c.y + (*box2).c.h <= (*box1).c.y))  // trop en haut
          return false;
  else
          return true;
}

//FONCTION collision entre projectile et batiment
bool colliProjBatiment (bullet* box1, bat* box2)
{
  if(((*box2).c.x >= (*box1).c.x + (*box1).c.w)      // trop à droite
     || ((*box2).c.x + (*box2).c.w <= (*box1).c.x) // trop à gauche
     || ((*box2).c.y >= (*box1).c.y + (*box1).c.h) // trop en bas
     || ((*box2).c.y + (*box2).c.h <= (*box1).c.y))  // trop en haut
          return false;
  else
          return true;
}

bool colliRam (player* box1, tank* box2)
{
  if(((*box2).c.x >= (*box1).c.x + (*box1).c.w)      // trop à droite
     || ((*box2).c.x + (*box2).c.w <= (*box1).c.x) // trop à gauche
     || ((*box2).c.y >= (*box1).c.y + (*box1).c.h) // trop en bas
     || ((*box2).c.y + (*box2).c.h <= (*box1).c.y))  // trop en haut
          return false;
 else
          return true;
}

void tir(bullet* B)
{
    (*B).c.x += (*B).v;
    if((*B).v>15)
        (*B).v-=2;
    (*B).a =(*B).a+1;
    (*B).c.y = (*B).c.y+(*B).a;
}

void tir_ennemi(bullet* B)
{
    (*B).c.x -= (*B).v;
    if((*B).v>15)
        (*B).v-=2;
    (*B).a =(*B).a-1;
    (*B).c.y = (*B).c.y-(*B).a;
}

SDL_Rect camera_offset(player P, SDL_Rect A)
{
    SDL_Rect offset;

    offset.x = A.x - P.c.x + PLAYER_IDLE;
    offset.y = A.y;
    offset.w = A.w;
    offset.h = A.h;

    return offset;
}

bool terrain_hit(bullet B, SDL_Point t[30])
{
    int i=1;
    while(t[i].x <= B.c.x + 75)
        i++;

    float dy = t[i].y-t[i-1].y;
    float dx = t[i].x-t[i-1].x;
    float a = dy/dx;
    float b = t[i-1].y - a*t[i-1].x;

    return (a*B.c.x + b < B.c.y);
}

SDL_Point pointSurSegment(SDL_Point A, SDL_Point B, int x)
{
    if(x >= A.x && x <= B.x)
    {
        float dy = B.y-A.y;
        float dx = B.x-A.x;
        float a = dy/dx;
        float b = A.y - a*A.x;

        return {x, a*x + b};
    }
    else return {x, SCREEN_H};
}


#endif
