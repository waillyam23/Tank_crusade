#include <iostream>
#include <fstream>
#include <ctime>
#include "SDL2/SDL.h"
#include "entities.h"
#include "utility.h"
#include "defines.h"

using namespace std;

int main(int argc, char *argv[])
{
    srand((double)time(NULL));
    //INITIALISATION DE LA LIBRAIRIE SDL

    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER);

    //initialisation des surfaces & textures de bases

    SDL_Window *window;     //La fenètre
    SDL_Renderer* renderer; //l'outil de rendu
    SDL_Surface* surface_background;    //la surface contenant l'image de fond
    SDL_Texture* texture_background;  //sprite de l'image de fond
    SDL_Rect camera ={0,0,SCREEN_W, SCREEN_H}; //création du rectangle de la caméra

    //initialisation des surfaces et textures supplémentaires

    SDL_Surface* surface_player;    //la surface contenant l'image du joueur
    SDL_Texture* texture_player;    //sprite du joueur
    SDL_Surface* surface_ennemis;   //la surface contenant l'image des ennemis
    SDL_Texture* texture_ennemis;   //sprite du ennemis
    SDL_Surface* surface_bullet;    //la surface contenant l'image de l'obus
    SDL_Texture* texture_bullet;    //sprite de l'obus
    SDL_Surface* surface_bullet_e;    //la surface contenant l'image de l'obus des ennemis
    SDL_Texture* texture_bullet_e;    //sprite de l'obus des ennemis
    SDL_Surface* surface_cursor;    //la surface contenant le curseur
    SDL_Texture* texture_cursor;    //sprite du curseur
    SDL_Surface* icon;  //icone du jeu
    SDL_Surface* surface_heart_full; //surface d'un coeur plein
    SDL_Texture* texture_heart_full; //sprite d'un coeur plein
    SDL_Surface* surface_heart_empty; //surface d'un coeur vide
    SDL_Texture* texture_heart_empty; //sprite d'un coeur vide
    SDL_Surface* surface_explosion1;
    SDL_Texture* texture_explosion1;
    SDL_Surface* surface_explosion2;
    SDL_Texture* texture_explosion2;
    SDL_Surface* surface_explosion3;
    SDL_Texture* texture_explosion3;
    SDL_Surface* surface_gameover;
    SDL_Texture* texture_gameover;

    //INITIALISATION DES VARIABLES

    //lecture/écriture du fichier des highscores
    ofstream highscores;
    highscores.open ("highscores.txt", ios::app);

    //variables pour afficher la date du highscore
    time_t ltime;
    struct tm *ptime;
    time(&ltime);   //ltime prend la date actuelle en secondes
    ptime = localtime(&ltime);  //pointeur vers la strucure tm


    //intégration de la résolution de l'écran
    SDL_DisplayMode DM;
    SDL_GetCurrentDisplayMode(0, &DM);
    DM.w = min(DM.w, SCREEN_W);
    DM.h = min(DM.h, SCREEN_H);

    //initialisation du joueur
    player p;
    initPlayer(&p);

    //variable du mode de jeu
    bool mouse = true;

    //variable pour afficher le terrain ou non (optimisation)
    bool terrain_shown = true;

    //initialisation de l'ennemi
    tank e;
    initEnnemi(&e, &p);

    //nombre aléatoire du spawn des ennemis
    int e_rand;

    //délais de tir aléa des ennemis
    int tir_d = 0;

    //niveau d'intelligence des ennemis
    int IA = 0;

    //frame de l'animation d'une explosion
    int explosion = 0;

    //frame de l'animation du game over
    int gameover = 0;

    //initialisation de l'obus du joueur
    bullet Bp;

    //initialisation de l'obus des ennemis
    bullet Be;

    SDL_Rect cursr;
    cursr.w=40;
    cursr.h=40;
    //coordonnées du curseur
    cursr.x=SCREEN_W/2;
    cursr.y=SCREEN_H/2; // coordonnées du curseur par rapport à la fenêtre

    //coordonnées du backgroud
    SDL_Rect destb;
    destb.x= 0;
    destb.y=0;
    destb.w=SCREEN_W;
    destb.h=SCREEN_H;

    int mouse_x, mouse_y; // coordonnées de la souris par rapport à la fenêtre

    SDL_Point terrain[30]={{0,0}}; //création des coordonnées du terrain
    procedural_init(terrain);

    //infos texture :
    Uint32 format;
    int tw; //largeur de la texture en pixel
    int th; //hauteur de la texture en pixel

    //LANCEMENT DE LA FENETRE

    window = SDL_CreateWindow("Tank_Crusade", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, DM.w, DM.h, SDL_WINDOW_MINIMIZED);


    //test si la fenetre est créée
      if(window==NULL)
	{
	  cout<<"erreur d'ouverture de SDL";
	  return 1;
	}

	//CHARGEMENT DES IMAGES

    surface_player = SDL_LoadBMP("./Textures/player_idle.bmp"); //charge l'image dans la surface
    surface_background = SDL_LoadBMP("./Textures/background.bmp");
    surface_gameover = SDL_LoadBMP("./Textures/GAME_OVER.bmp");
    surface_ennemis = SDL_LoadBMP("./Textures/tanks_tankNavy1.bmp");
    surface_bullet = SDL_LoadBMP("./Textures/bullet_player.bmp");
    surface_bullet_e = SDL_LoadBMP("./Textures/bullet_enemy.bmp");
    surface_cursor = SDL_LoadBMP("./Textures/cursor.bmp");
    surface_heart_full = SDL_LoadBMP("./Textures/heart_full.bmp");
    surface_heart_empty = SDL_LoadBMP("./Textures/heart_empty.bmp");
    surface_explosion1 = SDL_LoadBMP("./Textures/tank_explosion2.bmp");
    surface_explosion2 = SDL_LoadBMP("./Textures/tank_explosion3.bmp");
    surface_explosion3 = SDL_LoadBMP("./Textures/tank_explosion4.bmp");
    icon = SDL_LoadBMP("./Textures/player_idle.bmp");

    SDL_SetWindowIcon(window, icon); //création de l'icone du jeu


    //MISE A JOUR

      SDL_Event event; //nom général d'un évènement

      bool running=true;

      while(running) //boucle du jeu
	{
        //ENTREES CLAVIER & SOURIS
        SDL_ShowCursor(SDL_DISABLE); //on efface le cursuer de la souris

	    while(SDL_PollEvent(&event))
		{
            //conditions de fermeture de la fenêtre
		    if(event.type==SDL_QUIT || event.key.state == SDLK_ESCAPE)
			    running=false;

            if(event.key.state == SDLK_m)
            {
                if(mouse == true)
                {
                    mouse = false;
                    cursr.x = SCREEN_W/2;
                    cursr.y = SCREEN_H/2;
                }
                else
                    mouse = true;
            }

            if(mouse == true)
                if(SDL_GetMouseState(&mouse_x, &mouse_y) != SDL_BUTTON(1))
                {
                    cursr.x = mouse_x -20;
                    cursr.y = mouse_y -20;
                }

            if(event.key.state == SDLK_k )
                initEnnemi(&e, &p);

            if(event.key.state == SDLK_t ) //toogle terrain_shown
            {
                if (terrain_shown)
                    terrain_shown=false;
                else terrain_shown = true;
            }

            if(event.key.state == SDLK_o ) //change player movespeed
            {
                if (p.mspeed == 5)
                    p.mspeed = 50;
                else p.mspeed = 5;
            }

            if(event.key.state == SDLK_d)
                    p.c.x = p.c.x + p.mspeed;

            if(event.key.state == SDLK_q)
                if(!(p.c.x>PLAYER_IDLE && p.c.x < terrain[3].x))
                    p.c.x = p.c.x - p.mspeed;

            if(event.key.state == SDLK_z )  //déplace le curseur vers le haut
                cursr.y = cursr.y - 10;

            if(event.key.state == SDLK_s )  //déplace le curseur vers le bas
                cursr.y = cursr.y + 10;

            if(p.tir==false)   //teste si un il existe un autre obus
            {
                if(event.key.state == SDLK_SPACE)  //initilalise un obus si la barre espace est pressée
                    {
                        initBullet(&Bp,&p,cursr);
                        p.tir=true;
                    }
                if(SDL_GetMouseState(&mouse_x, &mouse_y) == SDL_BUTTON(1))
                {
                    initBullet(&Bp, &p, cursr);
                    p.tir=true;
                }
            }
		}

        //MISE À JOUR DE LA SIMULATION

        cameraCentered(&camera, &p);

        surLaLigneP (&p, terrain);
        surLaLigneE (&e, terrain);

        if(p.c.x-PLAYER_IDLE-MAX_BACKWARD > terrain[1].x)
            procedural_generation(terrain);

	    //CREATION DU RENDU

	    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	    SDL_Rect temporary; //variable temporaire stockant les offsets
	    SDL_Point terrain_offset[30]={{0,0}}; //vue du terrain avec camera


        //création de l'image de fond
	    texture_background = SDL_CreateTextureFromSurface(renderer,surface_background);
	    SDL_QueryTexture(texture_background,&format,NULL,&tw,&th);
	    SDL_RenderCopy(renderer,texture_background,NULL,&destb);

        if(e.hp>0)
	    {
            if(colliProjEnnemi(&Bp,&e)==true && explosion == 0)//conditions sur la collision des obus sur ennemis
            {
                e.hp -= 1;
                p.score += 1;
                p.tir=false;
                explosion = 1;
            }
            if(colliRam(&p,&e)==true && explosion == 0)//condition sur la collision entre tanks
            {
                e.hp -= 1;
                p.hp -= 1;
                explosion = 1;
            }
        }
        if(p.hp>0) //condition sur la collision de l'obus des ennemis et du joueur
        {
            if(colliProjJoueur(&Be, &p) == true && e.tir == true)
            {
                p.hp -= 1;
                e.tir = false;
            }
        }

	    //création de l'image de l'ennemi
        if(e.hp>0)
        {
            //activation du tir de l'ennemi
            if(tir_d == 30 && e.tir == false && e.c.x < p.c.x+1000)
            {
                tir_d = 0;
                initBullet_e(&Be, &e, IA);
                e.tir=true;
            }
            if(tir_d>30)
                tir_d = 0;

            //création de l'image de l'ennemi
            if(p.c.x>PLAYER_IDLE) // si le joueur a assez avancé
                temporary = camera_offset(p, e.c);
            else temporary = e.c;

            texture_ennemis = SDL_CreateTextureFromSurface(renderer,surface_ennemis);
            SDL_QueryTexture(texture_ennemis,&format,NULL,&tw,&th);
            SDL_RenderCopy(renderer,texture_ennemis,NULL,&temporary);

            if(Bp.c.y<e.c.y+80 && p.tir==true)
            {
                if(e.c.x<Bp.c.x)
                    e.c.x -= 5;
                else
                {
                    if(e.c.x>Bp.c.x)
                    e.c.x += 5;
                }
            }
            else e.c.x -= 2;
        }
        else if(e_rand == 5 && e.hp<1)
            initEnnemi(&e, &p);

        e_rand = rand()%(150);

        //création de l'image du joueur
        if(p.c.x>PLAYER_IDLE)
            temporary = camera_offset(p, p.c);
        else temporary = p.c;
	    texture_player = SDL_CreateTextureFromSurface(renderer,surface_player);
	    SDL_QueryTexture(texture_player,&format,NULL,&tw,&th);
	    SDL_RenderCopy(renderer,texture_player,NULL,&(temporary));

        //teste si tir_p est vrai et lance le calcul du tir
        if(p.tir==true)
        {
            tir(&Bp);

            //création de m'image de l'obus
            if(p.c.x>PLAYER_IDLE)
                temporary = camera_offset(p, Bp.c);
            else temporary = Bp.c;
            texture_bullet = SDL_CreateTextureFromSurface(renderer,surface_bullet);
            SDL_QueryTexture(texture_bullet,&format,NULL,&tw,&th);
            SDL_RenderCopy(renderer,texture_bullet,NULL,&temporary);
        }
        if(e.tir == true)
        {
            tir_ennemi(&Be);

            //création de m'image de l'obus ennemis
            if(p.c.x>PLAYER_IDLE)
                temporary = camera_offset(p, Be.c);
            else temporary = Be.c;
            texture_bullet_e = SDL_CreateTextureFromSurface(renderer,surface_bullet_e);
            SDL_QueryTexture(texture_bullet_e,&format,NULL,&tw,&th);
            SDL_RenderCopy(renderer,texture_bullet_e,NULL,&temporary);
        }

        //teste si l'obus actuel est encore dans la zone prédéfinie et le cas contraire, l'arrète
        if(terrain_hit(Bp, terrain))
            p.tir=false;

        //IA de l'ennemi
        if(terrain_hit(Be, terrain))
        {
            e.tir = false;
            if(Be.c.x<p.c.x)
                IA=1;
            if(Be.c.x>p.c.x)
                IA=2;
        }

	    //création du terrain
	    if(p.c.x>PLAYER_IDLE)
	    {
            for(int i=0; i<30; i++)
            {
                terrain_offset[i].x = terrain[i].x - p.c.x + PLAYER_IDLE;
                terrain_offset[i].y = terrain[i].y;
            }
            if(terrain_shown==true)
            {
                for(int i=0; i<=SCREEN_W; i++)
                    for(int j=0; j<29; j++)
                        if(terrain[j].x >= p.c.x-PLAYER_IDLE || terrain[j].x < p.c.x-PLAYER_IDLE+SCREEN_W)
                        {
                            SDL_SetRenderDrawColor(renderer, 106, 70, 41, SDL_ALPHA_OPAQUE);
                            SDL_Point pointLigne = pointSurSegment(terrain_offset[j], terrain_offset[j+1], i);
                            SDL_RenderDrawLine(renderer, pointLigne.x, pointLigne.y, pointLigne.x, SCREEN_H);
                        }

                SDL_SetRenderDrawColor(renderer, 30, 160, 50, SDL_ALPHA_OPAQUE);
                SDL_RenderDrawLines(renderer, terrain_offset, 30);
                for(int i=0; i<30; i++)
                    terrain_offset[i].y=terrain_offset[i].y-1;
                SDL_SetRenderDrawColor(renderer, 30, 180, 50, SDL_ALPHA_OPAQUE);
                SDL_RenderDrawLines(renderer, terrain_offset, 30);
            }
            else
            {
                SDL_SetRenderDrawColor(renderer, 255, 255, 255, SDL_ALPHA_OPAQUE);
                SDL_RenderDrawLines(renderer, terrain_offset, 30);
            }
	    }
	    else
	    {
            if(terrain_shown==true)
            {
                for(int i=0; i<=SCREEN_W; i++)
                    for(int j=0; j<29; j++)
                        if(terrain[j].x >= p.c.x-PLAYER_IDLE || terrain[j].x < p.c.x-PLAYER_IDLE+SCREEN_W)
                        {
                            SDL_SetRenderDrawColor(renderer, 106, 70, 41, SDL_ALPHA_OPAQUE);
                            SDL_Point pointLigne = pointSurSegment(terrain[j], terrain[j+1], i);
                            SDL_RenderDrawLine(renderer, pointLigne.x, pointLigne.y, pointLigne.x, SCREEN_H);
                        }
                SDL_SetRenderDrawColor(renderer, 30, 160, 50, SDL_ALPHA_OPAQUE);
                SDL_RenderDrawLines(renderer, terrain, 30);
                for(int i=0; i<30; i++)
                {
                    terrain_offset[i].y=terrain[i].y-1;
                    terrain_offset[i].x=terrain[i].x;
                }
                SDL_SetRenderDrawColor(renderer, 30, 180, 50, SDL_ALPHA_OPAQUE);
                SDL_RenderDrawLines(renderer, terrain_offset, 30);
            }
            else
            {
                SDL_SetRenderDrawColor(renderer, 255, 255, 255, SDL_ALPHA_OPAQUE);
                SDL_RenderDrawLines(renderer, terrain, 30);
            }
	    }

	    if(e.tir == false) //incrémentation des tirs ennemis
            tir_d += 1;

        //ANIMATION DES EXPLOSIONS

        if(explosion==3)
        {
            if(p.c.x>PLAYER_IDLE) // si le joueur a assez avancé
                temporary = camera_offset(p, e.c);
            else temporary = e.c;

            texture_explosion3 = SDL_CreateTextureFromSurface(renderer,surface_explosion3);
            SDL_QueryTexture(texture_explosion3,&format,NULL,&tw,&th);
            SDL_RenderCopy(renderer,texture_explosion3,NULL,&temporary);

            SDL_Delay(50);
            explosion = 0;
        }
        if(explosion==2)
        {
            if(p.c.x>PLAYER_IDLE) // si le joueur a assez avancé
                temporary = camera_offset(p, e.c);
            else temporary = e.c;

            texture_explosion2 = SDL_CreateTextureFromSurface(renderer,surface_explosion2);
            SDL_QueryTexture(texture_explosion2,&format,NULL,&tw,&th);
            SDL_RenderCopy(renderer,texture_explosion2,NULL,&temporary);

            SDL_Delay(50);
            explosion = 3;
        }
        if(explosion==1)
        {
            if(p.c.x>PLAYER_IDLE) // si le joueur a assez avancé
                temporary = camera_offset(p, e.c);
            else temporary = e.c;

            texture_explosion1 = SDL_CreateTextureFromSurface(renderer,surface_explosion1);
            SDL_QueryTexture(texture_explosion1,&format,NULL,&tw,&th);
            SDL_RenderCopy(renderer,texture_explosion1,NULL,&temporary);

            SDL_Delay(50);
            explosion = 2;
        }

        //ANIMATION DU GAMEOVER

        if(gameover==3)
        {
            if(p.c.x>PLAYER_IDLE)
                temporary = camera_offset(p, p.c);
            else temporary = p.c;

            texture_explosion3 = SDL_CreateTextureFromSurface(renderer,surface_explosion3);
            SDL_QueryTexture(texture_explosion3,&format,NULL,&tw,&th);
            SDL_RenderCopy(renderer,texture_explosion3,NULL,&temporary);

            texture_gameover = SDL_CreateTextureFromSurface(renderer,surface_gameover);
            SDL_QueryTexture(texture_gameover,&format,NULL,&tw,&th);
            SDL_RenderCopy(renderer,texture_gameover,NULL,&destb);

            running = false;
        }
        else if(gameover==2)
        {
            if(p.c.x>PLAYER_IDLE)
                temporary = camera_offset(p, p.c);
            else temporary = p.c;

            texture_explosion2 = SDL_CreateTextureFromSurface(renderer,surface_explosion2);
            SDL_QueryTexture(texture_explosion2,&format,NULL,&tw,&th);
            SDL_RenderCopy(renderer,texture_explosion2,NULL,&temporary);

            SDL_Delay(50);
            gameover = 3;
        }
        else if(gameover==1)
        {
            if(p.c.x>PLAYER_IDLE)
                temporary = camera_offset(p, p.c);
            else temporary = p.c;

            texture_explosion1 = SDL_CreateTextureFromSurface(renderer,surface_explosion1);
            SDL_QueryTexture(texture_explosion1,&format,NULL,&tw,&th);
            SDL_RenderCopy(renderer,texture_explosion1,NULL,&temporary);

            SDL_Delay(50);
            gameover = 2;
        }

	    //création des coeurs représentant les vies restantes du joueur
	    SDL_Rect Heart1 = {5,5,50,50};
	    SDL_Rect Heart2 = {60,5,50,50};
	    SDL_Rect Heart3 = {115,5,50,50};
	    texture_heart_full = SDL_CreateTextureFromSurface(renderer,surface_heart_full);
	    texture_heart_empty = SDL_CreateTextureFromSurface(renderer,surface_heart_empty);
        SDL_QueryTexture(texture_heart_full,&format,NULL,&tw,&th);
	    if(p.hp == 3)
	    {
            SDL_RenderCopy(renderer,texture_heart_full,NULL,&Heart1);
            SDL_RenderCopy(renderer,texture_heart_full,NULL,&Heart2);
            SDL_RenderCopy(renderer,texture_heart_full,NULL,&Heart3);
	    }
	    if(p.hp == 2)
	    {
            SDL_RenderCopy(renderer,texture_heart_full,NULL,&Heart1);
            SDL_RenderCopy(renderer,texture_heart_full,NULL,&Heart2);
            SDL_RenderCopy(renderer,texture_heart_empty,NULL,&Heart3);
	    }
	    if(p.hp == 1)
	    {
            SDL_RenderCopy(renderer,texture_heart_full,NULL,&Heart1);
            SDL_RenderCopy(renderer,texture_heart_empty,NULL,&Heart2);
            SDL_RenderCopy(renderer,texture_heart_empty,NULL,&Heart3);
	    }
	    if(p.hp == 0)
	    {
            SDL_RenderCopy(renderer,texture_heart_empty,NULL,&Heart1);
            SDL_RenderCopy(renderer,texture_heart_empty,NULL,&Heart2);
            SDL_RenderCopy(renderer,texture_heart_empty,NULL,&Heart3);
            if (gameover == 0)
                gameover=1;
	    }


	    //création du curseur
	    texture_cursor = SDL_CreateTextureFromSurface(renderer,surface_cursor);
	    SDL_QueryTexture(texture_cursor,&format,NULL,&tw,&th);
	    SDL_RenderCopy(renderer,texture_cursor,NULL,&cursr);


	    SDL_RenderPresent(renderer);    //création du rendu au premier plan
	    if(gameover == 3)
            SDL_Delay(5000);
	    SDL_RenderClear(renderer);      //mise au second plan du rendu
	    SDL_DestroyRenderer(renderer);  //supprime le rendu actuel
	    SDL_DestroyTexture(texture_player); //enlève l'image actuel du joueur pour le prochain rendu (libère l'espace mémoire)
	    SDL_DestroyTexture(texture_bullet); //enlève l'image actuel de l'obus pour le prochain rendu (libère l'espace mémoire)
	}

    //fermeture de la fenètre
    SDL_DestroyWindow(window);
    SDL_Quit();

    highscores << asctime(ptime) << "   Highscore : " << p.score << endl;
    highscores.close();

    return 0;
}
