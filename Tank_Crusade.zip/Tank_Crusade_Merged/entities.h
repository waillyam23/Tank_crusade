#ifndef __ENTITIES_H__   // si entities.h n'a pas encore été ajouté
#define __ENTITIES_H__   // alord dire au compilateur qu'il vient d'être ajouté

#include "SDL2/SDL.h"

//STRUCTURES DES ENTITEES

//Hitbox
struct hitbox{
    float x, y, w, h; //position des 4 coordonnées d'une hitbox rectangulaire
};

//Joueur
struct player{
    int hp;     //vie du joueur
    int score;  //score du joueur
    float a;    //angle du curseur
    SDL_Rect c; //coordonnées et hitbox du joueur
    int mspeed;//vitesse du joueur
    float bspeed;//vitesse des projectiles
    bool tir;//temps de rechargement
    float munition;//quelle munition ?
};

//Projectiles
struct bullet{
    SDL_Rect c; //coordonnées et hitbox du joueur
    float v;    //vitesse de
    float a;    //angle v
};

//Ennemis
struct tank{
    int hp;     //vie de l'ennemi
    SDL_Rect c; //coordonnées et hitbox du joueur
    float a;    //angle de tir de l'ennemi
    bool tir;

};

//Bâtiments
struct bat{
    int hp;       //vie du bêtiment
    SDL_Rect c; //coordonnées et hitbox du joueur
};

//PROTOTYPES DES FONCTIONS

void initPlayer (player* P1);

void initEnnemi (tank* T, player* P);

void initBullet (bullet* B, player* P1, SDL_Rect curseur);

void initBullet_e (bullet*B, tank* T, int IA);

#endif
