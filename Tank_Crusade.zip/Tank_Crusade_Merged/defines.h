#ifndef __DEFINES_CPP__
#define __DEFINES_CPP__

#define SCREEN_W 1500
#define SCREEN_H 800
#define PLAYER_W 80
#define PLAYER_H 70
#define CURV 150
#define PLAYER_IDLE SCREEN_W/4
#define MAX_BACKWARD SCREEN_W/2

#endif
